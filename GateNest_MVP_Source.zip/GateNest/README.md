# GateNest — Android MVP starter

GateNest is a Flutter UI prototype for a residential community app. It includes demo screens for residents, security guards and society admins; visitor/delivery registration; approve/reject and entry/exit demo actions; complaints; notices; and dashboard counts.

## Important: prototype only

This version keeps information only in app memory. Data resets when the app closes. It has no real login, cloud database, server-side permissions, or push notifications. Do not use it to control a real society gate or store real resident/visitor data yet.

## Build locally

With Flutter installed, run `flutter pub get` and `flutter build apk --release`. The APK is created at `build/app/outputs/flutter-apk/app-release.apk`.

## Next production steps

1. Add Firebase Authentication and a persistent database.
2. Enforce society-level data isolation and roles in database/server rules.
3. Add notifications, audit logs, backup/retention controls, and a privacy policy.
4. Test with dummy data and a security review before any live pilot.
