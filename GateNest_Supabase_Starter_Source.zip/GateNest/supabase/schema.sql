-- GateNest starter schema for Supabase (Postgres).
-- Run in Supabase SQL Editor on a NEW project. Review before applying to an existing database.
create extension if not exists pgcrypto;

create type public.gate_role as enum ('resident', 'guard', 'admin');

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null default '',
  created_at timestamptz not null default now()
);

create table public.societies (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  created_by uuid not null references auth.users(id),
  created_at timestamptz not null default now()
);

create table public.society_members (
  society_id uuid not null references public.societies(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  role public.gate_role not null default 'resident',
  flat_label text,
  active boolean not null default true,
  created_at timestamptz not null default now(),
  primary key (society_id, user_id)
);

create table public.visitor_requests (
  id uuid primary key default gen_random_uuid(),
  society_id uuid not null references public.societies(id) on delete cascade,
  created_by uuid not null references auth.users(id),
  visitor_name text not null,
  flat_label text not null,
  purpose text not null default 'Guest',
  status text not null default 'pending' check (status in ('pending','approved','rejected','checked_in','checked_out')),
  approved_by uuid references auth.users(id),
  checked_in_at timestamptz,
  checked_out_at timestamptz,
  created_at timestamptz not null default now()
);

create table public.complaints (
  id uuid primary key default gen_random_uuid(),
  society_id uuid not null references public.societies(id) on delete cascade,
  created_by uuid not null references auth.users(id),
  title text not null,
  details text not null default '',
  status text not null default 'open' check (status in ('open','in_progress','resolved','closed')),
  created_at timestamptz not null default now()
);

create table public.notices (
  id uuid primary key default gen_random_uuid(),
  society_id uuid not null references public.societies(id) on delete cascade,
  created_by uuid not null references auth.users(id),
  title text not null,
  body text not null,
  created_at timestamptz not null default now()
);

create table public.guard_attendance (
  id uuid primary key default gen_random_uuid(),
  society_id uuid not null references public.societies(id) on delete cascade,
  guard_id uuid not null references auth.users(id),
  event text not null check (event in ('check_in','check_out')),
  recorded_at timestamptz not null default now()
);

create index visitor_requests_society_created_idx on public.visitor_requests(society_id, created_at desc);
create index complaints_society_created_idx on public.complaints(society_id, created_at desc);
create index notices_society_created_idx on public.notices(society_id, created_at desc);

-- Security-definer helpers avoid recursive RLS checks on society_members.
create or replace function public.is_society_member(target_society uuid)
returns boolean language sql stable security definer set search_path = public
as $$ select exists (select 1 from public.society_members m where m.society_id = target_society and m.user_id = auth.uid() and m.active); $$;

create or replace function public.has_society_role(target_society uuid, allowed public.gate_role[])
returns boolean language sql stable security definer set search_path = public
as $$ select exists (select 1 from public.society_members m where m.society_id = target_society and m.user_id = auth.uid() and m.active and m.role = any(allowed)); $$;

alter table public.profiles enable row level security;
alter table public.societies enable row level security;
alter table public.society_members enable row level security;
alter table public.visitor_requests enable row level security;
alter table public.complaints enable row level security;
alter table public.notices enable row level security;
alter table public.guard_attendance enable row level security;

create policy "profiles read self" on public.profiles for select to authenticated using (id = auth.uid());
create policy "profiles create self" on public.profiles for insert to authenticated with check (id = auth.uid());
create policy "profiles update self" on public.profiles for update to authenticated using (id = auth.uid()) with check (id = auth.uid());

create policy "societies read as member" on public.societies for select to authenticated using (public.is_society_member(id));
create policy "societies create self" on public.societies for insert to authenticated with check (created_by = auth.uid());

create policy "members read own society" on public.society_members for select to authenticated using (user_id = auth.uid() or public.has_society_role(society_id, array['admin']::public.gate_role[]));
-- Membership invitations/role changes should be implemented through a trusted admin workflow, not client-side role editing.

create policy "visitors read society" on public.visitor_requests for select to authenticated using (public.is_society_member(society_id));
create policy "resident creates visitor" on public.visitor_requests for insert to authenticated with check (created_by = auth.uid() and public.has_society_role(society_id, array['resident','guard','admin']::public.gate_role[]));
create policy "guard or admin updates visitor" on public.visitor_requests for update to authenticated using (public.has_society_role(society_id, array['guard','admin']::public.gate_role[])) with check (public.has_society_role(society_id, array['guard','admin']::public.gate_role[]));

create policy "complaints read society" on public.complaints for select to authenticated using (public.is_society_member(society_id));
create policy "member creates complaint" on public.complaints for insert to authenticated with check (created_by = auth.uid() and public.is_society_member(society_id));
create policy "admin updates complaints" on public.complaints for update to authenticated using (public.has_society_role(society_id, array['admin']::public.gate_role[])) with check (public.has_society_role(society_id, array['admin']::public.gate_role[]));

create policy "notices read society" on public.notices for select to authenticated using (public.is_society_member(society_id));
create policy "admin creates notices" on public.notices for insert to authenticated with check (created_by = auth.uid() and public.has_society_role(society_id, array['admin']::public.gate_role[]));
create policy "admin updates notices" on public.notices for update to authenticated using (public.has_society_role(society_id, array['admin']::public.gate_role[])) with check (public.has_society_role(society_id, array['admin']::public.gate_role[]));

create policy "attendance read admin or self" on public.guard_attendance for select to authenticated using (guard_id = auth.uid() or public.has_society_role(society_id, array['admin']::public.gate_role[]));
create policy "guard records own attendance" on public.guard_attendance for insert to authenticated with check (guard_id = auth.uid() and public.has_society_role(society_id, array['guard','admin']::public.gate_role[]));
