# Build GateNest APK using only an Android phone

1. Create/sign in to a GitHub account at https://github.com/signup.
2. Create a **private** repository named `gatenest-app`.
3. On your phone, upload `GateNest_MVP_Source.zip` to the repository using **Add file → Upload files** and commit the upload.
4. In the repository, choose **Add file → Create new file**. Name it exactly `.github/workflows/build-apk.yml`.
5. Open the separate file `GateNest_BUILD_APK_WORKFLOW.yml` supplied with this project, copy all its contents, and paste them into the new GitHub file. Commit the file.
6. Open the repository's **Actions** tab. Choose **Build GateNest Android APK**, tap **Run workflow**, and confirm.
7. Wait for the run to finish with a green check. Open the run, scroll to **Artifacts**, and download `GateNest-Android-APK`.
8. Extract the downloaded artifact ZIP and tap `app-release.apk` to install. Android may ask you to allow installs from that source; only proceed if you trust the file and understand it is a demo prototype.

If a step fails, open the failed workflow run and share the error text or a screenshot so the build can be corrected.
