# GateNest — Supabase authentication starter

Flutter Android starter for GateNest. This revision adds Supabase email/password sign-up, sign-in, session-aware routing and sign-out, plus a starter multi-society SQL schema with row-level security policies.

## Status

- Supabase email/password authentication UI: included; requires build-time `SUPABASE_URL` and `SUPABASE_ANON_KEY` Dart defines.
- Starter SQL schema and RLS policies: `supabase/schema.sql`.
- Visitor, complaint, notice, attendance screens: still in-memory demo UI. They are **not connected to the cloud tables yet**.
- Membership invitation/role provisioning, password reset, audit logs, notifications and production review: not implemented.

See `SUPABASE_SETUP.md` for phone-only setup and GitHub Actions instructions. Do not use this build for live security decisions or real resident data.
