# Suggested production data model

Every tenant-owned document should carry `societyId`. Validate this on the server/database rules, not just in Flutter.

- `societies/{societyId}`: name, address, status, createdAt
- `users/{userId}`: displayName, phone, createdAt
- `memberships/{membershipId}`: userId, societyId, role, flatIds, active
- `flats/{flatId}`: societyId, building, flatNumber, residentUserIds
- `visitors/{visitorId}`: societyId, flatId, visitorName, purpose, createdBy, status, createdAt, approvedBy, approvedAt, checkedInAt, checkedOutAt
- `deliveries/{deliveryId}`: societyId, flatId, courierName, createdBy, status, createdAt, decisionAt
- `attendance/{attendanceId}`: societyId, guardUserId, eventType, timestamp
- `complaints/{complaintId}`: societyId, flatId, createdBy, title, description, status, createdAt, updatedAt
- `notices/{noticeId}`: societyId, createdBy, title, body, publishedAt, audience

## Access-control rules to implement

- Unauthenticated users cannot read or write private society records.
- Users must have an active membership for the requested society.
- Residents can approve requests only for their own flats.
- Guards can create visitor and delivery records only for their assigned society.
- Only admins can manage memberships, flats, and society-wide notices.
- Only authorized staff can change complaint status.
- Never trust a `role` or `societyId` supplied by the client without checking the authenticated user's membership.
- Minimize stored personal information and define retention/deletion policies.
