# GateNest + Supabase: phone-only setup

This starter adds **email/password sign-up, sign-in and sign-out** using Supabase Auth. The existing visitor/community screens are still demo-only and are not yet connected to cloud tables. Do not use this build for live gate decisions yet.

## 1. Create the Supabase project

1. On your Android phone, open https://supabase.com and create/sign in to an account.
2. Create a new project named `gatenest` and choose a strong database password. Save it somewhere safe; do not send it in chat.
3. In the project dashboard, open **Project Settings → API** (sometimes shown as **Connect**) and copy the **Project URL** and **anon/public key**. Never use or share the `service_role` key in the app or GitHub Actions.
4. Open **Authentication → Providers → Email** and enable email/password sign-in. For testing, leave email confirmation enabled and confirm the email sent to you.

## 2. Create the starter tables and security policies

1. In Supabase, open **SQL Editor → New query**.
2. Open `supabase/schema.sql` from this source package, copy all SQL, paste it into the query editor and run it.
3. This creates the first schema and row-level security policies. It is a starting point requiring a security review before real use. The client currently does not yet read/write these tables, and admin membership provisioning is intentionally not exposed to the app.

## 3. Configure GitHub Actions without putting keys in source code

In the GitHub repository `Mydream450/GateNest`:

1. Open **Settings → Secrets and variables → Actions → New repository secret**.
2. Add secret named `SUPABASE_URL` with the Supabase Project URL.
3. Add secret named `SUPABASE_ANON_KEY` with the Supabase anon/public key.
4. Update `.github/workflows/build-apk.yml` to pass these as Dart defines during the build. Under the `Build APK` step, use:

```yaml
      - name: Build APK
        working-directory: app
        env:
          SUPABASE_URL: ${{ secrets.SUPABASE_URL }}
          SUPABASE_ANON_KEY: ${{ secrets.SUPABASE_ANON_KEY }}
        run: flutter build apk --release --dart-define=SUPABASE_URL="$SUPABASE_URL" --dart-define=SUPABASE_ANON_KEY="$SUPABASE_ANON_KEY"
```

5. Replace the repository's `GateNest_MVP_Source.zip` with this updated source archive (same filename) and commit the change. Run the workflow again from **Actions**.

## 4. Test safely

1. Install the new APK, open GateNest, choose **Create an account**, use an email you control and a unique password, and follow the email confirmation if prompted.
2. Sign in. Sign out and sign in again to confirm the auth flow works.
3. Do not use real resident data yet. The demo UI is not yet wired to database reads/writes, society invitations, password reset, audit events, or production-ready role enforcement.

## Important security notes

- The anon/public key is designed for client use, but database security depends on correct Row Level Security (RLS). Never put a Supabase `service_role` key in a mobile app, source archive, or workflow.
- Do not make the GitHub repository public with secrets or resident data. Consider changing the repository visibility to **Private** under Settings → General.
- Supabase free-tier availability and quotas can change; check the dashboard's current plan before a real deployment.
- This package provides the first authentication step and schema foundation, not a production-ready society management system.
